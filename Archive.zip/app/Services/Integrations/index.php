<?php

add_action('init', function () {

    if (defined('FLUENTFORM')) {
        (new \FluentBooking\App\Services\Integrations\FluentForms\FluentFormInit())->init();
    }

    if (defined('FLUENTCRM')) {
        (new \FluentBooking\App\Services\Integrations\FluentCRM\FluentCrmInit());
        (new \FluentBooking\App\Services\Integrations\FluentCRM\Bootstrap());
    }

});


/*
 * Remote calendars
 */
(new \FluentBooking\App\Services\Integrations\Calendars\RemoteCalendarsInit())->boot();
(new \FluentBooking\App\Services\Integrations\Twilio\Bootstrap())->register();
(new \FluentBooking\App\Services\Integrations\ZoomMeeting\Bootstrap())->register();
(new \FluentBooking\App\Services\Integrations\Webhook\WebhookIntegration())->register();

// Global Notification Handler
(new \FluentBooking\App\Hooks\Handlers\GlobalNotificationHandler())->register();
