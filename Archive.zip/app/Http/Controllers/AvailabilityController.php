<?php

namespace FluentBooking\App\Http\Controllers;

use FluentBooking\App\Models\Availability;
use FluentBooking\App\Models\Calendar;
use FluentBooking\App\Models\CalendarSlot;
use FluentBooking\App\Services\Helper;
use FluentBooking\Framework\Request\Request;
use FluentBooking\App\Services\PermissionManager;
use FluentBooking\App\Services\SanitizeService;
use FluentBooking\App\Services\AvailabilityService;
use FluentBooking\App\Services\DateTimeHelper;
use FluentBooking\Framework\Support\Arr;

class AvailabilityController extends Controller
{
    public function index(Request $request)
    {
        $filters = $request->get('filters', []);

        $query = Availability::orderBy('id', 'desc');

        $host = Arr::get($filters, 'author');

        if ($host == 'me') {
            $host = get_current_user_id();
        } else if ($host !== 'all') {
            $host = (int)$host;
        }

        if (!PermissionManager::userCan(['read_and_use_other_availabilities','manage_other_availabilities'])) {
            $host = get_current_user_id();
        }

        if ($host && $host !== 'all') {
            $query->where('object_id', $host);
        }

        do_action_ref_array('fluent_booking/availability_schedules_query', [&$query]);

        $schedules = $query->paginate();


        do_action('fluent_booking/availability_schedules', $schedules);

        $formattedSchedules = [];
        foreach ($schedules as $schedule) {

            $timezone = Arr::get($schedule, 'value.timezone', 'UTC');

            $author = $schedule->getAuthor();

            $formattedSchedules[] = [
                'id'          => $schedule->id,
                'host_name'   => $author['name'],
                'host_avatar' => $author['avatar'],
                'title'       => $schedule->key,
                'usage_count' => AvailabilityService::getAvailabilityUsageCount($schedule->id),
                'created_at'  => $schedule->created_at->format('Y-m-d H:i:s'),
                'settings'    => [
                    'default'          => Arr::isTrue($schedule, 'value.default'),
                    'timezone'         => $timezone,
                    'date_overrides'   => SanitizeService::slotDateOverrides(Arr::get($schedule, 'value.date_overrides', []), 'UTC', $timezone),
                    'weekly_schedules' => SanitizeService::weeklySchedules(Arr::get($schedule, 'value.weekly_schedules', []), 'UTC', $timezone)
                ]
            ];
        }

        return [
            'availabilities' => [
                'data'     => $formattedSchedules,
                'total'    => $schedules->total(),
                'per_page' => $schedules->perPage(),
            ],
        ];
    }

    public function getSchedule(Request $request, $scheduleId)
    {
        $schedule = Availability::findOrFail($scheduleId);

        $formattedSchedule = AvailabilityService::getFormattedSchedule($schedule);

        return $this->sendSuccess([
            'schedule' => $formattedSchedule,
        ]);
    }

    public function getAvailabilityUsages(Request $request, $scheduleId)
    {
        $availabilityUsages = CalendarSlot::with(['calendar'])
            ->where('availability_type', 'existing_schedule')
            ->where('availability_id', $scheduleId)
            ->latest()
            ->paginate();

        return $this->sendSuccess([
            'usages' => $availabilityUsages
        ]);
    }

    public function createSchedule(Request $request)
    {
        $userId = get_current_user_id();

        $data = $request->all();

        $this->validate($data, [
            'title' => 'required',
        ]);

        $isTitleExist = AvailabilityService::isTitleAlreadyExist($data['title'], $userId);

        if ($isTitleExist) {
            $message = $data['title'] . ' is already exist';
            return $this->sendError([
                'message' => $message,
            ], 422);
        }

        $timezone = $request->get('timezone');

        if (!$timezone) {
            $calendar = Calendar::where('user_id', $userId)->first();
            if ($calendar) {
                $timezone = $calendar->author_timezone;
            } else {
                $timezone = 'UTC';
            }
        }

        // Check if the author has existing schedule
        $existingSchedule = Availability::where('object_id', $userId)->first();

        $scheduleData = AvailabilityService::createScheduleSchema($userId, $data['title'], !$existingSchedule, $timezone);

        $createdSchedule = Availability::create($scheduleData);

        do_action('fluent_booking/availability_schedule_created', $createdSchedule);

        return $this->sendSuccess([
            'schedule' => $createdSchedule,
            'message'  => __('Schedule has been created successfully', 'fluent-booking-pro'),
        ]);
    }

    public function cloneSchedule(Request $request)
    {
        $userId = get_current_user_id();

        $data = $request->all();

        $timezone       = Arr::get($data, 'settings.timezone');
        $weeklySchedule = Arr::get($data, 'settings.weekly_schedules');
        $dateOverrides  = Arr::get($data, 'settings.date_overrides');

        if (!$timezone) {
            $calendar = Calendar::where('user_id', $userId)->first();
            if ($calendar) {
                $timezone = $calendar->author_timezone;
            }
        }

        $scheduleData = AvailabilityService::createScheduleSchema($userId, $data['title'] . ' (Copy)', false, $timezone, 'UTC', $weeklySchedule, $dateOverrides);

        $createdSchedule = Availability::create($scheduleData);

        do_action('fluent_booking/availability_schedule_created', $createdSchedule);

        return $this->sendSuccess([
            'schedule' => $createdSchedule,
            'message'  => __('Schedule has been cloned successfully', 'fluent-booking-pro'),
        ]);
    }

    public function updateSchedule(Request $request, $scheduleId)
    {
        $userId = get_current_user_id();

        $schedule = Availability::findOrFail($scheduleId);

        $timezone = Arr::get($schedule, 'value.timezone');

        $data = $request->all();

        $scheduleData = [
            'default'          => Arr::isTrue($schedule, 'value.default'),
            'timezone'         => $timezone,
            'date_overrides'   => SanitizeService::slotDateOverrides(Arr::get($data, 'schedule.settings.date_overrides', []), $timezone, 'UTC'),
            'weekly_schedules' => SanitizeService::weeklySchedules(Arr::get($data, 'schedule.settings.weekly_schedules', []), $timezone, 'UTC'),
        ];

        $schedule->value = $scheduleData;
        $schedule->save();

        do_action('fluent_booking/avaibility_schedule_updated', $schedule, $scheduleData);

        return $this->sendSuccess([
            'message'  => __('Schedule has been updated successfully', 'fluent-booking-pro'),
            'schedule' => $schedule
        ]);
    }

    public function updateScheduleTitle(Request $request, $scheduleId)
    {
        $title = $request->get('title');

        $schedule = Availability::findOrFail($scheduleId);

        $isTitleExist = AvailabilityService::isTitleAlreadyExist($title, $schedule->object_id, $schedule->key);

        if ($isTitleExist) {
            $message = $title . ' is already exist';
            return $this->sendError([
                'message' => $message,
            ], 422);
        }

        $schedule->key = $title;
        $schedule->save();

        return $this->sendSuccess([
            'message' => __('Schedule title has been updated successfully', 'fluent-booking-pro'),
            'title'   => $schedule->key
        ]);
    }

    public function updateDefaultStatus(Request $request, $scheduleId)
    {
        $schedule = Availability::findOrFail($scheduleId);

        $updatedSettings = [
            'default'          => true,
            'timezone'         => Arr::get($schedule, 'value.timezone', 'UTC'),
            'date_overrides'   => Arr::get($schedule, 'value.data_overrides', []),
            'weekly_schedules' => Arr::get($schedule, 'value.weekly_schedules'),
        ];

        $schedule->value = $updatedSettings;
        $schedule->save();

        AvailabilityService::updateOtherDefaultStatus($schedule, $scheduleId);

        return $this->sendSuccess([
            'message' => __('Status has been updated successfully', 'fluent-booking-pro')
        ]);
    }

    public function deleteSchedule(Request $request, $scheduleId)
    {
        $schedule = Availability::findOrFail($scheduleId);

        $isDefault = Arr::isTrue($schedule, 'value.default');

        if ($isDefault) {
            return $this->sendError([
                'message' => __('Default Schedule can not be deleted', 'fluent-booking-pro')
            ], 422);
        }

        $usageCount = AvailabilityService::getAvailabilityUsageCount($scheduleId);

        if ($usageCount) {
            return $this->sendError([
                'message' => sprintf(__("Can't delete: %s events depend on this schedule", 'fluent-booking-pro'), $usageCount),
            ], 422);
        }

        $schedule->delete();

        return $this->sendSuccess([
            'message' => __('Schedule Availability has been deleted successfully', 'fluent-booking-pro')
        ]);
    }
}
